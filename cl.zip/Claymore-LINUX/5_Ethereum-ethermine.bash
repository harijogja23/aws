./ethdcrminer64 -epool eu1.ethermine.org:4444 -ewal 0x360d6f9efea21c82d341504366fd1c2eeea8fa9d -eworker asus -epsw x -mode 1 -dbg -1 -mport 0 -etha 0 -ftime 55 -retrydelay 1 -tt 79 -ttli 77 -tstop 89 



