#!/bin/bash

#################################
## Begin of user-editable part ##
#################################

POOL=eth-us-east1.nanopool.org:9999
WALLET=0x5991814469d402653916d52afa49c67af8f1d31b.PersatuanSuamiMenderita

#################################
##  End of user-editable part  ##
#################################

cd "$(dirname "$0")"

./lolMiner --algo ETHASH --pool $POOL --user $WALLET $@
while [ $? -eq 42 ]; do
    sleep 10s
    ./lolMiner --algo ETHASH --pool $POOL --user $WALLET $@
done
