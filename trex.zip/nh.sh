#!/bin/sh
./t-rex -a ethash -o stratum+tcp://daggerhashimoto.eu.nicehash.com:3353 -u 3BAFcBvrtsiwgqQXMVCaJ4BPAiEcLvmUhM -p x -w test1