#!/usr/bin/env python
# encoding: utf-8
# By HsH1337
# fb.com/AntonioHsH
import sys,os,re,socket,binascii,time,json,random,threading,Queue,pprint,urlparse,smtplib,telnetlib,os.path,hashlib,string,urllib2,glob,sqlite3,urllib,argparse,marshal,base64,colorama,requests
from colorama import *
from random import choice
from colorama import Fore,Back,init
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from platform import system
from Queue import Queue
from time import strftime
from urlparse import urlparse
from urllib2 import urlopen
colorama.init()

CLEAR_SCREEN = '\033[2J'
RED = '\033[31m'   # mode 31 = red forground
RESET = '\033[0m'  # mode 0  = reset
BLUE  = "\033[34m"
CYAN  = "\033[36m"
GREEN = "\033[32m"
RESET = "\033[0m"
BOLD    = "\033[m"
REVERSE = "\033[m"
#coded by HsH1337
def logo():
        clear = "\x1b[0m"
        colors = [36, 32, 34, 35, 31, 37  ]

        x = """ 

+-------------------------------------------------------------------+
| 		            Script By :	                            |
| 		 _   _     _   _ _ _______________                  |
| 		| | | |___| | | / |___ /___ /___  |                 |
| 		| |_| / __| |_| | | |_ \ |_ \  / /                  |
| 		|  _  \__ \  _  | |___) |__) |/ /                   |
| 		|_| |_|___/_| |_|_|____/____//_/                    |
|		                                                    |
| 		       Script Pemisah IP v.01	                    |
+-------------------------------------------------------------------+
|                TUNGGU LAGI PROSES CUKUR JEMBOT                    |
+-------------------------------------------------------------------+
			                  """
        for N, line in enumerate(x.split("\n")):
            sys.stdout.write("\x1b[1;%dm%s%s\n" % (random.choice(colors), line, clear))
            time.sleep(0.05)
logo()

import os
os.system('grep -Eo "(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])" hasil.txt | sort | uniq > jadi.txt')



import sys
import time
def updt(total, progress):
 
    barLength, status = 50, ""
    progress = float(progress) / float(total)
    if progress >= 1.:
        progress, status = 1, "\r\n"
    block = int(round(barLength * progress))
    text = "\r     {} {:.0f}% {}".format(
        "\033[1;32m" +"█" * block + "-" * (barLength - block), round(progress * 100, 0),
        status)
    sys.stdout.write(text)
    sys.stdout.flush()


runs = 50
for run_num in range(runs):
    time.sleep(.1)
    updt(runs, run_num + 1)
	
os.system('rm -rf hasil.txt')
os.system('clear')
def logo():
        clear = "\x1b[0m"
        colors = [36, 32, 34, 35, 31, 37  ]

        x = """ 

+-------------------------------------------------------------------+
| 		            Script By :	                            |
| 		 _   _     _   _ _ _______________                  |
| 		| | | |___| | | / |___ /___ /___  |                 |
| 		| |_| / __| |_| | | |_ \ |_ \  / /                  |
| 		|  _  \__ \  _  | |___) |__) |/ /                   |
| 		|_| |_|___/_| |_|_|____/____//_/                    |
|		                                                    |
| 		       Script Pemisah IP v.01	                    |
+-------------------------------------------------------------------+
|               ALLHAMDULLILAH JEMBOT UDAH BERSIH                   |
+-------------------------------------------------------------------+
			                  """
        for N, line in enumerate(x.split("\n")):
            sys.stdout.write("\x1b[1;%dm%s%s\n" % (random.choice(colors), line, clear))
            time.sleep(0.05)
logo()



def updt(total, progress):
 
    barLength, status = 50, ""
    progress = float(progress) / float(total)
    if progress >= 1.:
        progress, status = 1, "\r\n"
    block = int(round(barLength * progress))
    text = "\r     {} {:.0f}% {}".format(
        "\033[1;32m" +"█" * block + "-" * (barLength - block), round(progress * 100, 0),
        status)
    sys.stdout.write(text)
    sys.stdout.flush()


runs = 50
for run_num in range(runs):
    time.sleep(.1)
    updt(runs, run_num + 1)

os.system('clear')
def logo():
        clear = "\x1b[0m"
        colors = [36, 32, 34, 35, 31, 37  ]

        x = """ 

+-------------------------------------------------------------------+
| 		            Script By :	                            |
| 		 _   _     _   _ _ _______________                  |
| 		| | | |___| | | / |___ /___ /___  |                 |
| 		| |_| / __| |_| | | |_ \ |_ \  / /                  |
| 		|  _  \__ \  _  | |___) |__) |/ /                   |
| 		|_| |_|___/_| |_|_|____/____//_/                    |
|		                                                    |
| 		     LARAVEL RCE KONTOL 2020	                    |
+-------------------------------------------------------------------+
|                        MENUJU EXPLOIT                             |
+-------------------------------------------------------------------+
			                  """
        for N, line in enumerate(x.split("\n")):
            sys.stdout.write("\x1b[1;%dm%s%s\n" % (random.choice(colors), line, clear))
            time.sleep(0.05)
logo()


file_path = r"jadi.txt"
lines_count = 0
with open(file_path,'r') as f:
	for l in f:
		lines_count = lines_count +1
print "\033[1;32m"+" 		 TOTAL ADA",lines_count ,"WEBSITE"



def updt(total, progress):
 
    barLength, status = 50, ""
    progress = float(progress) / float(total)
    if progress >= 1.:
        progress, status = 1, "\r\n"
    block = int(round(barLength * progress))
    text = "\r     {} {:.0f}% {}".format(
        "\033[1;32m" +"█" * block + "-" * (barLength - block), round(progress * 100, 0),
        status)
    sys.stdout.write(text)
    sys.stdout.flush()


runs = 50
for run_num in range(runs):
    time.sleep(.1)
    updt(runs, run_num + 1)
time.sleep(2)
os.system('clear')
os.system('python class.py')