#!/usr/bin/env python
# encoding: utf-8
# By HsH1337
# fb.com/AntonioHsH
import sys,os,re,socket,binascii,time,json,random,threading,Queue,pprint,urlparse,smtplib,telnetlib,os.path,hashlib,string,urllib2,glob,sqlite3,urllib,argparse,marshal,base64,colorama,requests
from colorama import *
from random import choice
from colorama import Fore,Back,init
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from platform import system
from Queue import Queue
from time import strftime
from urlparse import urlparse
from urllib2 import urlopen
colorama.init()

CLEAR_SCREEN = '\033[2J'
RED = '\033[31m'   # mode 31 = red forground
RESET = '\033[0m'  # mode 0  = reset
BLUE  = "\033[34m"
CYAN  = "\033[36m"
GREEN = "\033[32m"
RESET = "\033[0m"
BOLD    = "\033[m"
REVERSE = "\033[m"
#coded by HsH1337
def logo():
        clear = "\x1b[0m"
        colors = [36, 32, 34, 35, 31, 37  ]

        x = """ 

+-------------------------------------------------------------------+
| 		            Script By :	                            |
| 		 _   _     _   _ _ _______________                  |
| 		| | | |___| | | / |___ /___ /___  |                 |
| 		| |_| / __| |_| | | |_ \ |_ \  / /                  |
| 		|  _  \__ \  _  | |___) |__) |/ /                   |
| 		|_| |_|___/_| |_|_|____/____//_/                    |
|		                                                    |
| 		    ROBOT PENCARI REJEKI V.01	                    |
+-------------------------------------------------------------------+
| Script Jadi Pada Hari Kamis Legi 19 November 2020  Jam 2:13 Siang |
+-------------------------------------------------------------------+
			                  """
        for N, line in enumerate(x.split("\n")):
            sys.stdout.write("\x1b[1;%dm%s%s\n" % (random.choice(colors), line, clear))
            time.sleep(0.05)
logo()
 
 
def mengetik(s):
    for c in s + '\n':
        sys.stdout.write(c)
        sys.stdout.flush()
#kecepatan mengetik
        time.sleep(random.random() * 0.1)
#ubah angka 0.1 sesuai keinginan kamu
#angka terkecil adalah yang paling cepat
#angka terbesar adalah yang paling lambat
mengetik('\033[1;32m'+'	Assalamualaikum warahmatullahi wabarakatuh\n\n	     Dengan jadinya script RPR V.01 ini\n	Kami Bersyukur dan Kami ucapkan terima kasih\n			  Wassalam\n\n\n 			    ^_^\n\n			     By\n			  Team Nguli\n		 HsH1337 | AnazMedia | Murdok\n\n')




def updt(total, progress):
 
    barLength, status = 23, ""
    progress = float(progress) / float(total)
    if progress >= 1.:
        progress, status = 1, "\r\n"
    block = int(round(barLength * progress))
    text = "\r{} {:.0f}% {}".format(
        "\033[1;32m"+"	PERSIAPAN  " +"█" * block + "-" * (barLength - block), round(progress * 100, 0),
        status)
    sys.stdout.write(text)
    sys.stdout.flush()


runs = 50
for run_num in range(runs):
    time.sleep(.1)
    updt(runs, run_num + 1)
	
time.sleep(3)
os.system('clear')
os.system('python assets.py')