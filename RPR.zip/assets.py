#!/usr/bin/env python
# encoding: utf-8
# By HsH1337
# fb.com/AntonioHsH
import sys,os,re,socket,binascii,time,json,random,threading,Queue,pprint,urlparse,smtplib,telnetlib,os.path,hashlib,string,urllib2,glob,sqlite3,urllib,argparse,marshal,base64,colorama,requests
from colorama import *
from random import choice
from colorama import Fore,Back,init
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from platform import system
from Queue import Queue
from time import strftime
from urlparse import urlparse
from urllib2 import urlopen
colorama.init()

CLEAR_SCREEN = '\033[2J'
RED = '\033[31m'   # mode 31 = red forground
RESET = '\033[0m'  # mode 0  = reset
BLUE  = "\033[34m"
CYAN  = "\033[36m"
GREEN = "\033[32m"
RESET = "\033[0m"
BOLD    = "\033[m"
REVERSE = "\033[m"
#coded by HsH1337
def logo():
        clear = "\x1b[0m"
        colors = [36, 32, 34, 35, 31, 37  ]

        x = """ 

+-------------------------------------------------------------------+
| 		            Script By :	                            |
| 		 _   _     _   _ _ _______________                  |
| 		| | | |___| | | / |___ /___ /___  |                 |
| 		| |_| / __| |_| | | |_ \ |_ \  / /                  |
| 		|  _  \__ \  _  | |___) |__) |/ /                   |
| 		|_| |_|___/_| |_|_|____/____//_/                    |
|		                                                    |
| 		    DOMAIN TO IP CHEKER MASAL	                    |
+-------------------------------------------------------------------+
|                 JAVADEFACER TEAM 2010 - 2014                      |
+-------------------------------------------------------------------+
			                  """
        for N, line in enumerate(x.split("\n")):
            sys.stdout.write("\x1b[1;%dm%s%s\n" % (random.choice(colors), line, clear))
            time.sleep(0.05)
logo()


def getIP(site):
	
		site = i.strip()
		try:
			if 'http://' not in site:
				IP1 = socket.gethostbyname(site)
				print "IP: "+IP1
				open('ips.txt', 'a').write(IP1+'/8'+'\n')
			elif 'http://' in site:
				url = site.replace('http://', '').replace('https://', '').replace('/', '')
				IP2 = socket.gethostbyname(url)
				print "\x1b[0m"+"\033[1;35m"+'*'+"\x1b[0m"+"\033[1;36m"+"  IP  "+"\x1b[0m"+":  "+"\033[1;32m"+IP2
				open('ips.txt', 'a').write(IP2+'\n')
	
		except:
			pass
			
nam=raw_input("\033[44;1m"+'[+] MASUKAN LIST DOMAIN [+]'+'\x1b[0m'+''+' : '+'\033[1;32m')
with open(nam) as f:
    for i in f:
        getIP(i)

		
os.system('clear')
print "\x1b[0m" +"\033[42;1m" '''
+-------------------------------------------------------------------+
|                PROSES DOMAIN TO IP SELESAI                        |
+-------------------------------------------------------------------+
''' "\x1b[0m"
 
def updt(total, progress):
 
    barLength, status = 66, ""
    progress = float(progress) / float(total)
    if progress >= 1.:
        progress, status = 1, "\r\n"
    block = int(round(barLength * progress))
    text = "\r{} {:.0f}% {}".format(
        "\033[1;32m" +"█" * block + "-" * (barLength - block), round(progress * 100, 0),
        status)
    sys.stdout.write(text)
    sys.stdout.flush()


runs = 50
for run_num in range(runs):
    time.sleep(.1)
    updt(runs, run_num + 1)

os.system('clear')

def logo():
        clear = "\x1b[0m"
        colors = [36, 32, 34, 35, 31, 37  ]

        x = """ 

+-------------------------------------------------------------------+
| 		            Script By :	                            |
| 		 _   _     _   _ _ _______________                  |
| 		| | | |___| | | / |___ /___ /___  |                 |
| 		| |_| / __| |_| | | |_ \ |_ \  / /                  |
| 		|  _  \__ \  _  | |___) |__) |/ /                   |
| 		|_| |_|___/_| |_|_|____/____//_/                    |
|		                                                    |
| 		       IP RANGE RANDOM V.01 	                    |
+-------------------------------------------------------------------+
|                        PROSES RANGE IP                            |
+-------------------------------------------------------------------+
			                  """
        for N, line in enumerate(x.split("\n")):
            sys.stdout.write("\x1b[1;%dm%s%s\n" % (random.choice(colors), line, clear))
            time.sleep(0.05)
logo()

os.system('masscan -p21,80,443,444,4040,8000,8001,8009,8010,8028,8029,8031,8032,8043,8044,8047,8049,8053,8080,9200 -iL ips.txt -oJ hasil.txt --rate=100000 --exclude 255.255.255.255')

print "\x1b[0m" +"\033[42;1m" '''
+-------------------------------------------------------------------+
|                PROSES RANGE IP SELESAI                            |
+-------------------------------------------------------------------+
''' "\x1b[0m"
 
def updt(total, progress):
 
    barLength, status = 66, ""
    progress = float(progress) / float(total)
    if progress >= 1.:
        progress, status = 1, "\r\n"
    block = int(round(barLength * progress))
    text = "\r{} {:.0f}% {}".format(
        "\033[1;32m" +"█" * block + "-" * (barLength - block), round(progress * 100, 0),
        status)
    sys.stdout.write(text)
    sys.stdout.flush()


runs = 50
for run_num in range(runs):
    time.sleep(.1)
    updt(runs, run_num + 1)
os.system('clear')
os.system('python banner.py')